'use strict';

var LiteBox = {};

LiteBox.addDragEvent = function (dom) {
  dom.dragging = false;
  dom.dragged = false;
  dom.addEventListener('mousedown', function (evt) {
    if ( 0 !== evt.button ) { return; }
    dom.dragX = evt.x;
    dom.dragY = evt.y;
    dom.dragging = true;
  }, false);
  dom.addEventListener('mousemove', function (evt) {
    if ( dom.dragging && (0 === evt.button) ) {
      dom.dragged = true;
      var posX = parseInt(dom.style.left) || 0;
      var posY = parseInt(dom.style.top) || window.scrollY;
      dom.style.left = (evt.x - dom.dragX + posX) + 'px';
      dom.style.top = (evt.y - dom.dragY + posY) + 'px';
      dom.dragX = evt.x;
      dom.dragY = evt.y;
    }
  }, true);
  dom.addEventListener('mouseup', function (evt) {
    if ( 0 !== evt.button ) { return; }
    dom.dragging = false;
  }, false);
};

LiteBox.addLiteBoxEvent = function (img) {
  img.addEventListener('click', function () {
    if ( !img.complete ) { return; }
    if ( img.cloned ) { return; }
    var clone = document.createElement('div');
    var nw = img.naturalWidth;
    var nh = img.naturalHeight;
    clone.style.cursor = 'pointer';
    clone.style.position = 'absolute';
    clone.style.zIndex = '99999999';
    clone.style.backgroundRepeat = 'no-repeat no-repeat';
    clone.style.backgroundColor = '#FAFAFA';
    clone.style.backgroundImage = 'url("' + img.src + '")';
    clone.style.padding = '0';
    clone.style.width = nw + 'px';
    clone.style.height = nh + 'px';
    clone.style.left = (window.innerWidth - nw) > 0 ? ((window.innerWidth - nw) / 2 + 'px') : '0';
    clone.style.top = (window.innerHeight - nh) > 0 ? ((window.scrollY + (window.innerHeight - nh) / 2) + 'px') : (window.scrollY + 'px');
    clone.style.border = '5px solid rgba(166, 181, 176, 0.5)';
    clone.addEventListener('click', function () {
      if ( clone.dragged ) {
        clone.dragged = false;
        return;
      }
      clone.remove();
      img.cloned = false;
    }, false);
    LiteBox.addDragEvent(clone);
    LiteBox.container.appendChild(clone);
    img.cloned = true;
  }, false);
};

LiteBox.addToLiteBox = function (pics) {
  if ( undefined !== pics.length ) {
    pics = [].slice.call(pics, 0);
  } else {
    pics = [].concat(pics);
  }
  pics = pics.filter(function (v) { return !!v; });
  if ( pics.length < 1 ) { return; }
  pics.forEach(LiteBox.addLiteBoxEvent);
};

(function (doc) {
  var setup = function () {
    doc.body.appendChild(LiteBox.container);
    LiteBox.addToLiteBox(document.querySelectorAll('article img'));
  };
  LiteBox.container = doc.createElement('div');
  LiteBox.container.setAttribute('id', 'LiteBox');
  if ( doc.readyState === 'loading' ) {
    doc.addEventListener('DOMContentLoaded', setup, false);
  } else {
    setTimeout(setup, 0);
  }
})(window.document);
