'use strict';

// article links
(function () {
  var date = document.querySelector('#content header .date');
  if ( !date ) { return; }
  // original link (text)
  var link = document.createElement('div');
  var url = window.location.origin + window.location.pathname.replace(/,\d+$/, '');
  //var url = window.location.href.replace(/#.*$/, '').replace(/\?[^?]*$/, '');
  link.setAttribute('class', 'srclink');
  link.innerHTML = '文章链接：<a href="' + url + '">' + url + '</a>';
  date.parentNode.insertBefore(link, date.nextSibling);
  // original link (QR code)
  var title = document.querySelector('#content header .title');
  var qrcode = document.createElement('img');
  qrcode.src = 'https://chart.googleapis.com/chart?cht=qr&chs=80x80&chld=L|0&choe=UTF-8&chl=' + url;
  qrcode.setAttribute('class', 'srcqr');
  title.parentNode.insertBefore(qrcode, title.nextSibling);
  // internal links for reference
  var reflinks = [].slice.call(document.querySelectorAll('#content article a.reference.internal:not([id])'));
  reflinks.forEach(function (link) {
    var reference = document.querySelector(link.getAttribute('href'));
    var title = reference.textContent.replace(/\[[^\]]+\]/, '').trim();
    link.setAttribute('title', title);
  });
  // internal links for footnote
  var folinks = [].slice.call(document.querySelectorAll('#content article a.footnote-reference'));
  folinks.forEach(function (link) {
    var reference = document.querySelector(link.getAttribute('href'));
    var title = reference.textContent.replace(/\[[^\]]+\]/, '').trim();
    link.setAttribute('title', title);
  });
  // external links
  var exlinks = [].slice.call(document.querySelectorAll('#content article a.external'));
  exlinks.forEach(function (link) {
    if ( link.textContent === link.getAttribute('href') ) {
      link.setAttribute('class', link.getAttribute('class') + " href");
    }
  });
})();

// print event?
(function () {
  var date = document.querySelector('#content header .date');
  if ( !date ) { return; }
  var button = document.createElement('span');
  button.id = 'print';
  button.textContent = '〔打印〕';
  button.addEventListener('click', function () {
    setTimeout(function () {
      window.print();
    }, 0);
  }, false);
  document.querySelector('#content header .title').appendChild(button);
})();

// FlowType: https://github.com/simplefocus/FlowType.JS/blob/master/flowtype.js
(function () {
  var change = function () {
    var maxWidth = 960, minWidth = 450;
    var maxSize = 16, minSize = 12;
    var fontRatio = 35, lineRatio = 1.45;
    var elem = document.body;
    var elemWidth = elem.getClientRects()[0].width;
    var width = elemWidth > maxWidth ? maxWidth
                : elemWidth < minWidth ? minWidth
                : elemWidth;
    var fontBase = width / fontRatio;
    var fontSize = fontBase > maxSize ? maxSize
                   : fontBase < minSize ? minSize
                   : fontBase;
    elem.style.fontSize = fontSize + 'px';
    //elem.style.lineHeight = fontSize*lineRatio + 'px';
  };
  window.addEventListener('resize', change, true);
  change();
})();

// Feed
(function () {
  var link = document.querySelector('#main-nav a[href*="feed"]');
  link.addEventListener('click', function (evt) {
    evt.preventDefault();
    prompt('本博客文章的 RSS 订阅地址是：', link.href);
  }, false);
})();
