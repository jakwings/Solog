(function(a){MathJax.Hub.Insert(a.mo.prototype,{OPTABLE:{infix:{"\u03f6":a.mo.OPTYPES.REL}}});MathJax.Ajax.loadComplete(a.optableDir+"/GreekAndCoptic.js")})(MathJax.ElementJax.mml);
