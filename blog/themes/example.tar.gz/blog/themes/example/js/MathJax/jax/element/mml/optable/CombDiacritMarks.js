(function(a){MathJax.Hub.Insert(a.mo.prototype,{OPTABLE:{postfix:{"\u0311":a.mo.OPTYPES.ACCENT}}});MathJax.Ajax.loadComplete(a.optableDir+"/CombDiacritMarks.js")})(MathJax.ElementJax.mml);
