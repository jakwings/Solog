<!DOCTYPE html>
<html lang="<?php echo $theme->mCfg['web_language']; ?>" dir="<?php echo $theme->mCfg['web_direction']; ?>">
<?php include_once $theme->mDirAbs . '/partial/head.php'; ?>
<body>
  <div id="main">
    <?php include_once $theme->mDirAbs . '/partial/header.php'; ?>
    <div id="body" class="post">
      <?php include_once $theme->mDirAbs . '/partial/nav-categories.php'; ?>
      <div id="content">
        <header class="tex2jax_ignore">
          <h1 class="title"><?php echo htmlentities($data['article']['title'], ENT_QUOTES, 'UTF-8'); ?></h1>
          <?php if ( $data['type'] === 'post' ) { ?>
            <div class="date">
              <?php include_once $theme->mDirAbs . '/partial/date.php'; ?>
            </div>
            <div class="classification">
              <?php include_once $theme->mDirAbs . '/partial/categories.php'; ?>
              <?php include_once $theme->mDirAbs . '/partial/tags.php'; ?>
            </div>
          <?php } ?>
        </header>
        <article>
          <?php echo $data['article']['content']; ?>
        </article>
        <footer class="tex2jax_ignore">
          <?php
            if ( $data['type'] === 'post' ) {
              include_once $theme->mDirAbs . '/partial/nav-posts.php';
            }
          ?>
          <?php
            if ( $data['article']['comment'] ) {
              include_once $theme->mDirAbs . '/partial/comments.php';
            } else {
              echo '<div class="clearfix"></div>';
              echo '<div id="comments" class="disabled">[ 评论区未启用 ]</div>';
            }
          ?>
        </footer>
      </div>
    </div>
    <?php include_once $theme->mDirAbs . '/partial/footer.php'; ?>
  </div>
</body>
</html>
